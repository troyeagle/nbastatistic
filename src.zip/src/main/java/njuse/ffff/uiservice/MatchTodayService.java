package njuse.ffff.uiservice;

public interface MatchTodayService {

	void setTodayMatches(Object[][] data);
}
