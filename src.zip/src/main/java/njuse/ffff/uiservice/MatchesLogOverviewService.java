package njuse.ffff.uiservice;

import java.util.Map;

public interface MatchesLogOverviewService {

	void setGameLog(Map<Integer, Object[][]> data);
}
