package njuse.ffff.uiservice;

public interface PlayerFilterViewService {

	String[] getFilters();
	
	void setResult(Object[][] data);
}
