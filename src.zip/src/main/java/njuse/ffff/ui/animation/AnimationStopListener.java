package njuse.ffff.ui.animation;

public interface AnimationStopListener {

	public void perform();
}
