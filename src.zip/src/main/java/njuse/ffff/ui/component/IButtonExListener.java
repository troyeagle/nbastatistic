package njuse.ffff.ui.component;

import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelListener;

public interface IButtonExListener extends MouseListener, MouseWheelListener,
		MouseMotionListener {

}
