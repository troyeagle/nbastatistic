package njuse.ffff.ui.ver2.component;

public interface SwitchListener {

	public void actionPerformed(SwitchEvent e);
}
