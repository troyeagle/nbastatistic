package njuse.ffff.ui.ver2;

import java.util.Map;

import njuse.ffff.uiservice.MatchesLogOverviewService;

public class MatchsViewPane implements MatchesLogOverviewService {

	@Override
	public void setGameLog(Map<Integer, Object[][]> data) {
		
	}

}
