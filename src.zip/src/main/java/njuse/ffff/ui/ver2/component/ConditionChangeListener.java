package njuse.ffff.ui.ver2.component;

public interface ConditionChangeListener {

	void actionPerformed(ConditionChangeEvent e);
}
