package njuse.ffff.ui.ver2;

public interface UIConfigNotifier {

	/**
	 * 通知UI设置变更
	 */
	void notifyChange();
}
