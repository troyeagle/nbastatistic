package njuse.ffff.ui.ver2;

public enum UIEventType {
	ALL, BUSY, FINISH, SWITCH, SEARCH
}
