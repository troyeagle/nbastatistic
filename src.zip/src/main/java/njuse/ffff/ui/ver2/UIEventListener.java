package njuse.ffff.ui.ver2;

public interface UIEventListener {

	public void actionPerformed(UIEvent e);
}
