package njuse.ffff.ui.ver2.component;

import javax.swing.JButton;
import javax.swing.plaf.basic.BasicScrollBarUI;

public class ScrollBarUI extends BasicScrollBarUI {

	@Override
	protected JButton createDecreaseButton(int orientation) {
		return super.createDecreaseButton(orientation);
	}
}
