package njuse.ffff.presenterService;

public interface UpdateService {
	//数据更新后，通知界面逻辑层更新数据
	public void informUpdate();
}
