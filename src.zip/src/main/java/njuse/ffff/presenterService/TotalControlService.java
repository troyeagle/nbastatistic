package njuse.ffff.presenterService;


public interface TotalControlService {
	//初始化系统
	public void initSystem();
	//回退到上个界面
	public void backToLastPanel();
}
