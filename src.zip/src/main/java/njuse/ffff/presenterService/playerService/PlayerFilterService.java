package njuse.ffff.presenterService.playerService;

import njuse.ffff.uiservice.PlayerFilterViewService;

public interface PlayerFilterService {
	//传送球员筛选条件
	public void setPlayerFilterResult(PlayerFilterViewService panel);
}
