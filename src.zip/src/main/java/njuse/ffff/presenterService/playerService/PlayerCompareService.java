package njuse.ffff.presenterService.playerService;

import njuse.ffff.uiservice.PlayersOverviewService;

public interface PlayerCompareService {
	//设置某一赛季的球员信息横向比较界面
	public void setPlayerCompareInfoForSeason(PlayersOverviewService playerViewPanel);
}
