package njuse.ffff.presenterService.hotEventService;

import njuse.ffff.uiservice.SpecialViewService;

public interface HotEventService {
	//设置热点界面
	public void setHotEventPanel(SpecialViewService panel);
}
