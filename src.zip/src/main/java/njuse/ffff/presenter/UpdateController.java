package njuse.ffff.presenter;

import njuse.ffff.presenterService.UpdateService;

public class UpdateController implements UpdateService{

	/**
	 * 数据更新后，通知界面逻辑层更新数据
	 */
	public void informUpdate() {
		// TODO 自动生成的方法存根,更新放缓
		
	}

}
