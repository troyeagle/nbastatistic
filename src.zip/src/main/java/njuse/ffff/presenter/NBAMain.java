package njuse.ffff.presenter;

public class NBAMain {
	public static void main(String[] args) {
		TotalUIController.getInstance().initSys();;
	}
}
