package njuse.ffff.data;

import java.io.IOException;

import org.testng.annotations.Test;

public class TotalTest {
  @Test
  public void f() throws IOException{
	  DataReadController dr = new DataReadController();
	  dr.initialize();
  }
}
