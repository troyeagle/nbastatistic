package njuse.ffff.data;

import static org.junit.Assert.*;

import java.io.IOException;

import org.testng.annotations.Test;

public class TeamDataReaderTest {

	@Test
	public void test() throws IOException {
		TeamDataProcessor team = new TeamDataProcessor();
		//team.readAndAnalysisTeam();
		assertTrue(true);
	}

}
